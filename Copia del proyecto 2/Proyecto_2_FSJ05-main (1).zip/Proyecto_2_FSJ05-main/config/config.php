<?php
    //CREANDO CONSTANTES
    
    //Almacenar mi controlador (representa la "c")
    define("CONTROLADOR_PRINCIPAL", "Libros");

    //Almacenar mi acción (representa la "a")
    define("ACCION_PRINCIPAL", "index");

?>
