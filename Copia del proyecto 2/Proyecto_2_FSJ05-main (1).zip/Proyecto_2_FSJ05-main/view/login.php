<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGIN</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="box">
        <div class="form">
            <h2>Inicio de Sesion</h2>
            <div class="inputBox">
                <input type="text" required="required">
                <span>Usuario: </span>
                <i></i>
            </div>
            <div class="inputBox">
                <input type="password" required="required">
                <span>Contraseña :</span>
                <i></i>
            </div>
            <br>
            <input type="submit" value="Login">
        </div>
    </div>
</body>
</html>